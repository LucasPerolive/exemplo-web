import boto3
import dash
from dash import dcc, html
from flask import Flask
from datetime import datetime, timedelta
import plotly.express as px

# Criar app Flask + Dash
server = Flask(__name__)
app = dash.Dash(__name__, server=server)

# Configurar cliente do AWS Cost Explorer (REMOVA CREDENCIAIS E USE VARIÁVEIS DE AMBIENTE)
client = boto3.client(
    'ce',
    aws_access_key_id='AKIA2UC3CJR5KP6A7WFI',
    aws_secret_access_key='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',
    region_name='sa-east-1'
)

def get_aws_costs():
    """Obtém os custos da AWS nos últimos 30 dias e calcula o total."""
    end_date = datetime.today().date()
    start_date = end_date - timedelta(days=30)

    response = client.get_cost_and_usage(
        TimePeriod={'Start': str(start_date), 'End': str(end_date)},
        Granularity='MONTHLY',
        Metrics=['UnblendedCost'],
        GroupBy=[{'Type': 'DIMENSION', 'Key': 'SERVICE'}]
    )

    costs = []
    total_cost = 0.0

    for entry in response['ResultsByTime']:
        for group in entry["Groups"]:
            service = group["Keys"][0]
            amount = float(group["Metrics"]["UnblendedCost"]["Amount"])
            if amount > 0:
                costs.append((service, amount))
                total_cost += amount

    return costs, total_cost

# Layout do Dash
app.layout = html.Div(className="container", children=[
    html.H1("Monitoramento de Custos AWS", className="title"),
    
    html.Div(className="card", children=[
        html.H2("Custo Total: $0.00", id="total-cost", className="total-cost"),
        html.P("Este painel mostra a distribuição dos custos da AWS nos últimos 30 dias."),
        
        dcc.Dropdown(
            id='chart-type',
            options=[
                {'label': 'Gráfico de Pizza', 'value': 'pie'},
                {'label': 'Gráfico de Barras', 'value': 'bar'}
            ],
            value='pie',  # Valor padrão
            clearable=False,
            style={"width": "50%"}
        ),

        dcc.Graph(id='cost-chart', style={"width": "100%"})
    ])
])

@app.callback(
    [dash.Output('cost-chart', 'figure'),
     dash.Output('total-cost', 'children')],
    [dash.Input('chart-type', 'value')]
)
def update_chart(chart_type):
    """Atualiza o gráfico e ajusta para o tipo selecionado."""
    costs, total_cost = get_aws_costs()

    if not costs:
        return {}, f"Custo Total: $0.00"

    services, amounts = zip(*costs)

    # Gera o gráfico baseado no tipo selecionado
    if chart_type == 'pie':
        fig = px.pie(values=amounts, names=services, title="Custos da AWS - Gráfico de Pizza")
    elif chart_type == 'bar':
        fig = px.bar(x=services, y=amounts, title="Custos da AWS - Gráfico de Barras", labels={'x': 'Serviços', 'y': 'Custo'})

    fig.update_layout(margin=dict(l=40, r=40, t=50, b=50))

    return fig, f"Custo Total: ${total_cost:,.2f}"

# Rodar o app
if __name__ == '__main__':
    app.run(debug=True)
